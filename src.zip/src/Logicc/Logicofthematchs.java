package Logicc;

import Back.ReyPlus;

import java.util.Random;
import java.util.SortedMap;

public class Logicofthematchs {

    public static void main(String[] args) {
    Random a = new Random();
        int i = a.nextInt(0, 1100);
        if (i>2){
            System.out.println("Yuttti");
        }
        else {
            System.out.println("Looox");
        }
    }
}
