package Logicc;

import Back.Oyinchi;
import Front.Color;

import java.util.ArrayList;
import java.util.Scanner;

public class Menyuuu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
//        Oyibchi oyibchi = new
        String a = "   " + Color.BLUE + Oyinchi.getIsm()+ Color.RESET + "                     "+
                 "\n|---------------------------|------------------|"+
                 "\n|Keyingi oyinga otish un    |Magazinga kirish  |"+
                 "\n|'D'knopkasini bosing       |un 'M'knopkasini  |"+
                 "\n|                           |bosin             |"+
                 "\n|                           |                  |"+
                 "\n|---------------------------|------------------|"+
                 "\n|" +  Oyinchi.getSastav() +"|"+
                 "\n|                                              |"+
                 "\n|                                              |"+
                 "\n|----------------------------------------------|";
        System.out.println(a);
        String md = scanner.next();
        if (md == "m"){

        }
    }


}
