package Logicc;

import Back.BBVA_Teams;
import Back.Oyinchi;
import Back.PlRe;
import Front.Color;
import Front.Util;

import java.util.Scanner;

import static Back.PlRe.player;

public class CreateAcc2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n\nHi!\nOtingiz nma?");
        String usism = scanner.next();
        System.out.println("Hello! " + Color.BLUE + usism + Color.RESET + Color.YELLOW + " Fifa.Bekhruz Edition " + Color.RESET + "ga xush kelbsz!\nBu yerda sz Mezza qb FottbalTeam Menagment bn shug'ilanolisiz.   ");
        System.out.println("\n1.Siz uje mavjud teamga menager bolmoxchmsiz?\n2.Yoki ozis ozingizni Teamizga menager bolmoxchimisiz?");
        int choose = scanner.nextInt();
        switch (choose) {
            case 1 -> {
                BBVA_Teams[] values = BBVA_Teams.values();
                for (int i = 0; i < values.length; i++) {
                    System.out.print(Color.YELLOW + (i + 1) + "." + Color.RESET);
                    System.out.print(Color.BLUE + values[i].nomi + Color.RESET);
                    System.out.println(" Klubni budjeti: " + Color.GREEN + values[i].budj + Color.RESET);
                }
                int chtem = scanner.nextInt();
                System.out.println(values[chtem-1].nomi);
                System.out.println(values[chtem-1].budj);
                Menyuuu.main(args);
                switch (chtem) {
                    case 1 -> {
                        TeamBBVA.BBva_team_menag("FC Barcelona");

                         new Oyinchi(usism, BBVA_Teams.BARCELONA, PlRe.Barca);
                        Menyuuu.main(args);
                    }
                    case 2 -> {
                        TeamBBVA.BBva_team_menag("Real Madrid");
                        Oyinchi oyinchi = new Oyinchi(usism, BBVA_Teams.REAL_MADRID,  PlRe.Real_M);
                        Menyuuu.main(args);
                    }
                    case 3 -> {
                        TeamBBVA.BBva_team_menag("Atletico Madrid");
                        Oyinchi oyinchi = new Oyinchi(usism, BBVA_Teams.ATLETICO, PlRe.Atletico);
                    }
                    case 4 -> {
                        TeamBBVA.BBva_team_menag("Seviliya");
                        Oyinchi oyinchi = new Oyinchi(usism, BBVA_Teams.SEVILIYA, PlRe.Secili);
                    }
                    case 5 -> {
                        TeamBBVA.BBva_team_menag("Jirona");
                        Oyinchi oyinchi = new Oyinchi(usism, BBVA_Teams.JIRONA, PlRe.Jirona);
                    }
                    case 6 -> {
                        TeamBBVA.BBva_team_menag("Atletik");
                        Oyinchi oyinchi = new Oyinchi(usism, BBVA_Teams.BILBAO, PlRe.Bilbao);
                    }
                    case 7 -> {
                        TeamBBVA.BBva_team_menag("Valenciya");
                        Oyinchi oyinchi = new Oyinchi(usism, BBVA_Teams.VALENCIYA, PlRe.Valen);
                    }
                    case 8 -> {
                        TeamBBVA.BBva_team_menag("Kadis");
                        Oyinchi oyinchi = new Oyinchi(usism, BBVA_Teams.KADIS, PlRe.Kadis);
                    }
                    case 9 -> {
                        TeamBBVA.BBva_team_menag("Hetafe");
                        Oyinchi oyinchi = new Oyinchi(usism, BBVA_Teams.HETAFE, player);
                    }
                    case 10 -> {
                        TeamBBVA.BBva_team_menag("Real Betis");
                        Oyinchi oyinchi = new Oyinchi(usism, BBVA_Teams.REAL_BETIS, player);
                    }
                    case 11 -> {
                        TeamBBVA.BBva_team_menag("Real sosedad");
                        Oyinchi oyinchi = new Oyinchi(usism, BBVA_Teams.REAL_SOSEDAD, player);
                    }
                    case 12 -> {
                        TeamBBVA.BBva_team_menag("Osasuna");
                        Oyinchi oyinchi = new Oyinchi(usism, BBVA_Teams.OSASUNA, player);
                    }
                    case 13 -> {
                        TeamBBVA.BBva_team_menag("Villiareal");
                        Oyinchi oyinchi = new Oyinchi(usism, BBVA_Teams.VILLIAREAL, player);
                    }
                    case 14 -> {
                        TeamBBVA.BBva_team_menag("Alaves");
                        Oyinchi oyinchi = new Oyinchi(usism, BBVA_Teams.ALAVES, player);
                    }
                    case 15 -> {
                        TeamBBVA.BBva_team_menag("MAlroka");
                        Oyinchi oyinchi = new Oyinchi(usism, BBVA_Teams.MALORKA, player);
                    }
                    case 16 -> {
                        TeamBBVA.BBva_team_menag("Selta");
                        Oyinchi oyinchi = new Oyinchi(usism, BBVA_Teams.SELTA, player);
                    }
                    case 17 -> {
                        TeamBBVA.BBva_team_menag("Granda");
                        Oyinchi oyinchi = new Oyinchi(usism, BBVA_Teams.GRANDA, player);
                    }
                    case 18 -> {
                        TeamBBVA.BBva_team_menag("Almeriya");
                        Oyinchi oyinchi = new Oyinchi(usism, BBVA_Teams.ALMERIYA, player);
                    }
                    case 19 -> {
                        TeamBBVA.BBva_team_menag("Las palmas");
                        Oyinchi oyinchi = new Oyinchi(usism, BBVA_Teams.LAS_PALMAS, player);
                    }
                    case 20 -> {
                        TeamBBVA.BBva_team_menag("Rayo Valeykano");
                        Oyinchi oyinchi = new Oyinchi(usism, BBVA_Teams.RAYO_VALEYKANO, player);
                    }
                    default -> {
                        System.out.println("Programm error, try again");
                        CreateAcc.main(args);
                    }
                }

            }
            case 2 -> {
            }
            default -> {
                Util.printStr("Programm error. Try again", Color.RED);
                main(args);
            }
        }

    }
}
