package Front;

import Front.Color;

public class Util {
    public static void printStr(String str,String color){
        System.out.println(color + str + Color.RESET);
    }
}
