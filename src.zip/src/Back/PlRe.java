package Back;

import java.util.ArrayList;
import java.util.List;

public class PlRe {
    public static ArrayList<User> Barca = new ArrayList<>();
    public static ArrayList<User> Real_M = new ArrayList<>();
    public static ArrayList<User> Atletico = new ArrayList<>();
    public static ArrayList<User> Secili = new ArrayList<>();
    public static ArrayList<User> Jirona = new ArrayList<>();
    public static ArrayList<User> Bilbao = new ArrayList<>();
    public static ArrayList<User> Valen = new ArrayList<>();
    public static ArrayList<User> player = new ArrayList<>();
    public static ArrayList<User> Kadis = new ArrayList<>();
    public static ArrayList<User> Oyibchilar = new ArrayList<>();

    static {
        //Barca

        Barca.add(new User("Suarez",92,BBVA_Teams.BARCELONA, "ST",120000000));
        Barca.add(new User("Neymar",93,BBVA_Teams.BARCELONA, "ST",180000000));
        Barca.add(new User("Messi",95,BBVA_Teams.BARCELONA, "ST",180000000));
        Barca.add(new User("S.Busquets",86,BBVA_Teams.BARCELONA, "CM",6000000));
        Barca.add(new User("Iniesta",89,BBVA_Teams.BARCELONA, "CM",65000000));
        Barca.add(new User("Rakitic'",87,BBVA_Teams.BARCELONA, "CM",75000000));
        Barca.add(new User("Umtiti",85,BBVA_Teams.BARCELONA, "CB",100000000));
        Barca.add(new User("Pique",86,BBVA_Teams.BARCELONA, "CB",35000000));
        Barca.add(new User("S.Roberto",81,BBVA_Teams.BARCELONA, "CB",55000000));
        Barca.add(new User("Jordi Alba",87,BBVA_Teams.BARCELONA, "CB",65000000));
        Barca.add(new User("Ter-Stegen",85,BBVA_Teams.BARCELONA, "GK",80000000));
        //Real-Madrid
        Real_M.add(new User("C.Ronaldo",94,BBVA_Teams.REAL_MADRID, "ST",180000000));
        Real_M.add(new User("Benzema",83,BBVA_Teams.REAL_MADRID, "ST",80000000));
        Real_M.add(new User("Bale",90,BBVA_Teams.REAL_MADRID, "ST",120000000));
        Real_M.add(new User("Kross'",91,BBVA_Teams.REAL_MADRID, "CM",90000000));
        Real_M.add(new User("Modric'",91,BBVA_Teams.REAL_MADRID, "CM",860000000));
        Real_M.add(new User("Rodriguez",89,BBVA_Teams.REAL_MADRID, "CM",130000000));
        Real_M.add(new User("Sergio RAmos",91,BBVA_Teams.REAL_MADRID, "CB",45000000));
        Real_M.add(new User("Varane",83,BBVA_Teams.REAL_MADRID, "CB",5500000));
        Real_M.add(new User("Carvajal",87,BBVA_Teams.REAL_MADRID, "CB",35000000));
        Real_M.add(new User("Marcelo",89,BBVA_Teams.REAL_MADRID, "CB",40000000));
        Real_M.add(new User("Navas",87,BBVA_Teams.REAL_MADRID, "GK",100000000));
//        Atletico
//        Atletico.add(new User("Grizman",89,BBVA_Teams.ATLETICO, "ST"));
//        Atletico.add(new User("Gameiro",88,BBVA_Teams.ATLETICO, "ST"));
//        Atletico.add(new User("Carrasco",84,BBVA_Teams.ATLETICO, "ST"));
//        Atletico.add(new User("Koke",86,BBVA_Teams.ATLETICO, "CM"));
//        Atletico.add(new User("Gabi",85,BBVA_Teams.ATLETICO, "CM"));
//        Atletico.add(new User("Saul",86,BBVA_Teams.ATLETICO, "CM"));
//        Atletico.add(new User("Fellipe Luis",78,BBVA_Teams.ATLETICO, "CB"));
//        Atletico.add(new User("Juanfran",79,BBVA_Teams.ATLETICO, "CB"));
//        Atletico.add(new User("Savic'",80,BBVA_Teams.ATLETICO, "CB"));
//        Atletico.add(new User("Godin",82,BBVA_Teams.ATLETICO, "CB"));
//        Atletico.add(new User("Oblak",89,BBVA_Teams.ATLETICO, "GK"));
//        //Seviliya
//        Secili.add(new User("Evgeniy",79,BBVA_Teams.SEVILIYA, "ST"));
//        Secili.add(new User("Hoakin",73,BBVA_Teams.SEVILIYA, "ST"));
//        Secili.add(new User("Lusianno",72,BBVA_Teams.SEVILIYA, "ST"));
//        Secili.add(new User("Iborra",86,BBVA_Teams.SEVILIYA, "CM"));
//        Secili.add(new User("Steve",76,BBVA_Teams.SEVILIYA, "CM"));
//        Secili.add(new User("Matias",75,BBVA_Teams.SEVILIYA, "CM"));
//        Secili.add(new User("Eskudero",85,BBVA_Teams.SEVILIYA, "CB"));
//        Secili.add(new User("Lenglet",78,BBVA_Teams.SEVILIYA, "CB"));
//        Secili.add(new User("MAriano'",80,BBVA_Teams.SEVILIYA, "CB"));
//        Secili.add(new User("Timote",82,BBVA_Teams.SEVILIYA, "CB"));
//        Secili.add(new User("Segio Roki",79,BBVA_Teams.SEVILIYA, "GK"));
//        //Jirona
//        Jirona.add(new User("Mikle",79,BBVA_Teams.JIRONA, "ST"));
//        Jirona.add(new User("Portu",73,BBVA_Teams.JIRONA, "ST"));
//        Jirona.add(new User("Xristian",72,BBVA_Teams.JIRONA, "ST"));
//        Jirona.add(new User("David",86,BBVA_Teams.JIRONA, "CM"));
//        Jirona.add(new User("Pere Pons",76,BBVA_Teams.JIRONA, "CM"));
//        Jirona.add(new User("Alex",75,BBVA_Teams.JIRONA, "CM"));
//        Jirona.add(new User("Pedro",85,BBVA_Teams.JIRONA, "CB"));
//        Jirona.add(new User("Xonas",78,BBVA_Teams.JIRONA, "CB"));
//        Jirona.add(new User("Huanpe",80,BBVA_Teams.JIRONA, "CB"));
//        Jirona.add(new User("Bernardo",82,BBVA_Teams.JIRONA, "CB"));
//        Jirona.add(new User("Gorka",79,BBVA_Teams.JIRONA, "GK"));
//        //Bilbao
//        Bilbao.add(new User("Iker",79,BBVA_Teams.BILBAO, "ST"));
//        Bilbao.add(new User("Markel",73,BBVA_Teams.BILBAO, "ST"));
//        Bilbao.add(new User("Mikel Sanxose",72,BBVA_Teams.BILBAO, "ST"));
//        Bilbao.add(new User("Xavi Erroso",86,BBVA_Teams.BILBAO, "CM"));
//        Bilbao.add(new User("Gorka",76,BBVA_Teams.BILBAO, "CM"));
//        Bilbao.add(new User("OSkar",75,BBVA_Teams.BILBAO, "CM"));
//        Bilbao.add(new User("Xabi",85,BBVA_Teams.BILBAO, "CB"));
//        Bilbao.add(new User("Inigo",78,BBVA_Teams.BILBAO, "CB"));
//        Bilbao.add(new User("Emerik",80,BBVA_Teams.BILBAO, "CB"));
//        Bilbao.add(new User("Eneko",82,BBVA_Teams.BILBAO, "CB"));
//        Bilbao.add(new User("Alex",79,BBVA_Teams.BILBAO, "GK"));
//        //Valenciya
//        Valen.add(new User("Gansalu",79,BBVA_Teams.VALENCIYA, "ST"));
//        Valen.add(new User("Lusiano",73,BBVA_Teams.VALENCIYA, "ST"));
//        Valen.add(new User("Simon",72,BBVA_Teams.VALENCIYA, "ST"));
//        Valen.add(new User("Nacho",86,BBVA_Teams.VALENCIYA, "CM"));
//        Valen.add(new User("Andreas",76,BBVA_Teams.VALENCIYA, "CM"));
//        Valen.add(new User("MArtin",75,BBVA_Teams.VALENCIYA, "CM"));
//        Valen.add(new User("Tony",85,BBVA_Teams.VALENCIYA, "CB"));
//        Valen.add(new User("Xose",78,BBVA_Teams.VALENCIYA, "CB"));
//        Valen.add(new User("Jackson",80,BBVA_Teams.VALENCIYA, "CB"));
//        Valen.add(new User("Ruben",82,BBVA_Teams.VALENCIYA, "CB"));
//        Valen.add(new User("Neto",79,BBVA_Teams.VALENCIYA, "GK"));
//        //Kadis
//        Kadis.add(new User("Mikle",79,BBVA_Teams.KADIS, "ST"));
//        Kadis.add(new User("Frankli",73,BBVA_Teams.KADIS, "ST"));
//        Kadis.add(new User("Artur",72,BBVA_Teams.KADIS, "ST"));
//        Kadis.add(new User("John",86,BBVA_Teams.KADIS, "CM"));
//        Kadis.add(new User("Jack",76,BBVA_Teams.KADIS, "CM"));
//        Kadis.add(new User("Rick",75,BBVA_Teams.KADIS, "CM"));
//        Kadis.add(new User("Bro",85,BBVA_Teams.KADIS, "CB"));
//        Kadis.add(new User("Riko",78,BBVA_Teams.KADIS, "CB"));
//        Kadis.add(new User("Jinanji",80,BBVA_Teams.KADIS, "CB"));
//        Kadis.add(new User("hjolaand",82,BBVA_Teams.KADIS, "CB"));
//        Kadis.add(new User("De broooyne",79,BBVA_Teams.KADIS, "GK"));
//        //Hetafe
//        player.add(new User("Mikle",79,BBVA_Teams.HETAFE, "ST"));
//        player.add(new User("Portu",73,BBVA_Teams.HETAFE, "ST"));
//        player.add(new User("Xristian",72,BBVA_Teams.HETAFE, "ST"));
//        player.add(new User("David",86,BBVA_Teams.HETAFE, "CM"));
//        player.add(new User("Pere Pons",76,BBVA_Teams.HETAFE, "CM"));
//        player.add(new User("Alex",75,BBVA_Teams.HETAFE, "CM"));
//        player.add(new User("Pedro",85,BBVA_Teams.HETAFE, "CB"));
//        player.add(new User("Xonas",78,BBVA_Teams.HETAFE, "CB"));
//        player.add(new User("Huanpe",80,BBVA_Teams.HETAFE, "CB"));
//        player.add(new User("Bernardo",82,BBVA_Teams.HETAFE, "CB"));
//        player.add(new User("Gorka",79,BBVA_Teams.HETAFE, "GK"));
//        //REalSosedad
//        player.add(new User("Mikle",79,BBVA_Teams.REAL_SOSEDAD, "ST"));
//        player.add(new User("Portu",73,BBVA_Teams.REAL_SOSEDAD, "ST"));
//        player.add(new User("Xristian",72,BBVA_Teams.REAL_SOSEDAD, "ST"));
//        player.add(new User("David",86,BBVA_Teams.REAL_SOSEDAD, "CM"));
//        player.add(new User("Pere Pons",76,BBVA_Teams.REAL_SOSEDAD, "CM"));
//        player.add(new User("Alex",75,BBVA_Teams.REAL_SOSEDAD, "CM"));
//        player.add(new User("Pedro",85,BBVA_Teams.REAL_SOSEDAD, "CB"));
//        player.add(new User("Xonas",78,BBVA_Teams.REAL_SOSEDAD, "CB"));
//        player.add(new User("Huanpe",80,BBVA_Teams.REAL_SOSEDAD, "CB"));
//        player.add(new User("Bernardo",82,BBVA_Teams.REAL_SOSEDAD, "CB"));
//        player.add(new User("Gorka",79,BBVA_Teams.REAL_SOSEDAD, "GK"));
//        //Osasuna
//        player.add(new User("Mikle",79,BBVA_Teams.OSASUNA, "ST"));
//        player.add(new User("Portu",73,BBVA_Teams.OSASUNA, "ST"));
//        player.add(new User("Xristian",72,BBVA_Teams.OSASUNA, "ST"));
//        player.add(new User("David",86,BBVA_Teams.OSASUNA, "CM"));
//        player.add(new User("Pere Pons",76,BBVA_Teams.OSASUNA, "CM"));
//        player.add(new User("Alex",75,BBVA_Teams.OSASUNA, "CM"));
//        player.add(new User("Pedro",85,BBVA_Teams.OSASUNA, "CB"));
//        player.add(new User("Xonas",78,BBVA_Teams.OSASUNA, "CB"));
//        player.add(new User("Huanpe",80,BBVA_Teams.OSASUNA, "CB"));
//        player.add(new User("Bernardo",82,BBVA_Teams.OSASUNA, "CB"));
//        player.add(new User("Gorka",79,BBVA_Teams.OSASUNA, "GK"));
//        //Villiareal
//        player.add(new User("Mikle",79,BBVA_Teams.VILLIAREAL, "ST"));
//        player.add(new User("Portu",73,BBVA_Teams.VILLIAREAL, "ST"));
//        player.add(new User("Xristian",72,BBVA_Teams.VILLIAREAL, "ST"));
//        player.add(new User("David",86,BBVA_Teams.VILLIAREAL, "CM"));
//        player.add(new User("Pere Pons",76,BBVA_Teams.VILLIAREAL, "CM"));
//        player.add(new User("Alex",75,BBVA_Teams.VILLIAREAL, "CM"));
//        player.add(new User("Pedro",85,BBVA_Teams.VILLIAREAL, "CB"));
//        player.add(new User("Xonas",78,BBVA_Teams.VILLIAREAL, "CB"));
//        player.add(new User("Huanpe",80,BBVA_Teams.VILLIAREAL, "CB"));
//        player.add(new User("Bernardo",82,BBVA_Teams.VILLIAREAL, "CB"));
//        player.add(new User("Gorka",79,BBVA_Teams.VILLIAREAL, "GK"));
//        //Alaves
//        player.add(new User("Mikle",79,BBVA_Teams.ALAVES, "ST"));
//        player.add(new User("Portu",73,BBVA_Teams.ALAVES, "ST"));
//        player.add(new User("Xristian",72,BBVA_Teams.ALAVES, "ST"));
//        player.add(new User("David",86,BBVA_Teams.ALAVES, "CM"));
//        player.add(new User("Pere Pons",76,BBVA_Teams.ALAVES, "CM"));
//        player.add(new User("Alex",75,BBVA_Teams.ALAVES, "CM"));
//        player.add(new User("Pedro",85,BBVA_Teams.ALAVES, "CB"));
//        player.add(new User("Xonas",78,BBVA_Teams.ALAVES, "CB"));
//        player.add(new User("Huanpe",80,BBVA_Teams.ALAVES, "CB"));
//        player.add(new User("Bernardo",82,BBVA_Teams.ALAVES, "CB"));
//        player.add(new User("Gorka",79,BBVA_Teams.ALAVES, "GK"));
//        //Molorka
//        player.add(new User("Mikle",79,BBVA_Teams.MALORKA, "ST"));
//        player.add(new User("Portu",73,BBVA_Teams.MALORKA, "ST"));
//        player.add(new User("Xristian",72,BBVA_Teams.MALORKA, "ST"));
//        player.add(new User("David",86,BBVA_Teams.MALORKA, "CM"));
//        player.add(new User("Pere Pons",76,BBVA_Teams.MALORKA, "CM"));
//        player.add(new User("Alex",75,BBVA_Teams.MALORKA, "CM"));
//        player.add(new User("Pedro",85,BBVA_Teams.MALORKA, "CB"));
//        player.add(new User("Xonas",78,BBVA_Teams.MALORKA, "CB"));
//        player.add(new User("Huanpe",80,BBVA_Teams.MALORKA, "CB"));
//        player.add(new User("Bernardo",82,BBVA_Teams.MALORKA, "CB"));
//        player.add(new User("Gorka",79,BBVA_Teams.MALORKA, "GK"));
//        //Selta
//        player.add(new User("Mikle",79,BBVA_Teams.SELTA, "ST"));
//        player.add(new User("Portu",73,BBVA_Teams.SELTA, "ST"));
//        player.add(new User("Xristian",72,BBVA_Teams.SELTA, "ST"));
//        player.add(new User("David",86,BBVA_Teams.SELTA, "CM"));
//        player.add(new User("Pere Pons",76,BBVA_Teams.SELTA, "CM"));
//        player.add(new User("Alex",75,BBVA_Teams.SELTA, "CM"));
//        player.add(new User("Pedro",85,BBVA_Teams.SELTA, "CB"));
//        player.add(new User("Xonas",78,BBVA_Teams.SELTA, "CB"));
//        player.add(new User("Huanpe",80,BBVA_Teams.SELTA, "CB"));
//        player.add(new User("Bernardo",82,BBVA_Teams.SELTA, "CB"));
//        player.add(new User("Gorka",79,BBVA_Teams.SELTA, "GK"));
//        //Granda
//        player.add(new User("Mikle",79,BBVA_Teams.GRANDA, "ST"));
//        player.add(new User("Portu",73,BBVA_Teams.GRANDA, "ST"));
//        player.add(new User("Xristian",72,BBVA_Teams.GRANDA, "ST"));
//        player.add(new User("David",86,BBVA_Teams.GRANDA, "CM"));
//        player.add(new User("Pere Pons",76,BBVA_Teams.GRANDA, "CM"));
//        player.add(new User("Alex",75,BBVA_Teams.GRANDA, "CM"));
//        player.add(new User("Pedro",85,BBVA_Teams.GRANDA, "CB"));
//        player.add(new User("Xonas",78,BBVA_Teams.GRANDA, "CB"));
//        player.add(new User("Huanpe",80,BBVA_Teams.GRANDA, "CB"));
//        player.add(new User("Bernardo",82,BBVA_Teams.GRANDA, "CB"));
//        player.add(new User("Gorka",79,BBVA_Teams.GRANDA, "GK"));
//        //Almeriya
//        player.add(new User("Mikle",79,BBVA_Teams.ALMERIYA, "ST"));
//        player.add(new User("Portu",73,BBVA_Teams.ALMERIYA, "ST"));
//        player.add(new User("Xristian",72,BBVA_Teams.ALMERIYA, "ST"));
//        player.add(new User("David",86,BBVA_Teams.ALMERIYA, "CM"));
//        player.add(new User("Pere Pons",76,BBVA_Teams.ALMERIYA, "CM"));
//        player.add(new User("Alex",75,BBVA_Teams.ALMERIYA, "CM"));
//        player.add(new User("Pedro",85,BBVA_Teams.ALMERIYA, "CB"));
//        player.add(new User("Xonas",78,BBVA_Teams.ALMERIYA, "CB"));
//        player.add(new User("Huanpe",80,BBVA_Teams.ALMERIYA, "CB"));
//        player.add(new User("Bernardo",82,BBVA_Teams.ALMERIYA, "CB"));
//        player.add(new User("Gorka",79,BBVA_Teams.ALMERIYA, "GK"));
//        //Laspalmas
//        player.add(new User("Mikle",79,BBVA_Teams.LAS_PALMAS, "ST"));
//        player.add(new User("Portu",73,BBVA_Teams.LAS_PALMAS, "ST"));
//        player.add(new User("Xristian",72,BBVA_Teams.LAS_PALMAS, "ST"));
//        player.add(new User("David",86,BBVA_Teams.LAS_PALMAS, "CM"));
//        player.add(new User("Pere Pons",76,BBVA_Teams.LAS_PALMAS, "CM"));
//        player.add(new User("Alex",75,BBVA_Teams.LAS_PALMAS, "CM"));
//        player.add(new User("Pedro",85,BBVA_Teams.LAS_PALMAS, "CB"));
//        player.add(new User("Xonas",78,BBVA_Teams.LAS_PALMAS, "CB"));
//        player.add(new User("Huanpe",80,BBVA_Teams.LAS_PALMAS, "CB"));
//        player.add(new User("Bernardo",82,BBVA_Teams.LAS_PALMAS, "CB"));
//        player.add(new User("Gorka",79,BBVA_Teams.LAS_PALMAS, "GK"));
//        //Rayo
//        player.add(new User("Mikle",79,BBVA_Teams.RAYO_VALEYKANO, "ST"));
//        player.add(new User("Portu",73,BBVA_Teams.RAYO_VALEYKANO, "ST"));
//        player.add(new User("Xristian",72,BBVA_Teams.RAYO_VALEYKANO, "ST"));
//        player.add(new User("David",86,BBVA_Teams.RAYO_VALEYKANO, "CM"));
//        player.add(new User("Pere Pons",76,BBVA_Teams.RAYO_VALEYKANO, "CM"));
//        player.add(new User("Alex",75,BBVA_Teams.RAYO_VALEYKANO, "CM"));
//        player.add(new User("Pedro",85,BBVA_Teams.RAYO_VALEYKANO, "CB"));
//        player.add(new User("Xonas",78,BBVA_Teams.RAYO_VALEYKANO, "CB"));
//        player.add(new User("Huanpe",80,BBVA_Teams.RAYO_VALEYKANO, "CB"));
//        player.add(new User("Bernardo",82,BBVA_Teams.RAYO_VALEYKANO, "CB"));
//        player.add(new User("Gorka",79,BBVA_Teams.RAYO_VALEYKANO, "GK"));
    }
}
