package Back;

import java.util.ArrayList;

public class Oyinchi {
    private static String ism;
    private static BBVA_Teams jamo;
    private static ArrayList<User> sastav;

    public Oyinchi(String ism, BBVA_Teams jamo, ArrayList<User> sastav) {
        this.ism = ism;
        this.jamo = jamo;
        this.sastav = sastav;
    }

    public  static String getIsm() {
        return ism;
    }

    public void setIsm(String ism) {
        this.ism = ism;
    }

    public static BBVA_Teams getJamo() {
        return jamo;
    }

    public void setJamo(BBVA_Teams jamo) {
        this.jamo = jamo;
    }

    public static ArrayList<User> getSastav() {
        return sastav;
    }

    public void setSastav(ArrayList<User> sastav) {
        this.sastav = sastav;
    }
}
