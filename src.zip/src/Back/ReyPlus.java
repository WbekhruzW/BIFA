package Back;

public class ReyPlus {
    public static void rey(int a,int p,int l,int o,int i,int u,int y,int t,int r,int e,int w){
        int reypluspl = a+p+l+o+i+u+y+t+r+e+w;
        System.out.println(reypluspl);
    }
}
