package Back;

public class Magazm {
    public static void main(String[] args) {
        System.out.println(
                PlRe.Barca
        );
        System.out.println(PlRe.Kadis);
        System.out.println(PlRe.Valen);
        System.out.println(PlRe.Bilbao);
        System.out.println(PlRe.Jirona);
        System.out.println(PlRe.Secili);
        System.out.println(PlRe.Real_M);
        System.out.println(PlRe.Atletico);
        System.out.println("\n"+PlRe.player);
    }
}
