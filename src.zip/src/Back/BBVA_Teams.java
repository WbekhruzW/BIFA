package Back;

import java.util.ArrayList;
import java.util.List;

public enum BBVA_Teams {
    BARCELONA("FC Barcelona",250000),
    REAL_MADRID("Real Madrid",350000),
    ATLETICO("Atletico Madrid",200000),
    SEVILIYA("Seviliya",150000),
    JIRONA("Jirona",70000),
    BILBAO("Atletik",60000),
    VALENCIYA("Valenciya",90000),
    KADIS("Kadis",50000),
    HETAFE("Hetafe",40000),
    REAL_BETIS("Real Betis",110000),
    REAL_SOSEDAD("Real sosedad",110000),
    OSASUNA("Osasuna",140000),
    VILLIAREAL("Villiareal",130000),
    ALAVES("Alaves",90000),
    MALORKA("MAlroka",60000),
    SELTA("Selta",40000),
    GRANDA("Granda",50000),
    ALMERIYA("Almeriya",80000),
    LAS_PALMAS("Las palmas",60000),
    RAYO_VALEYKANO("Rayo Valeykano",90000);

    public String nomi;
    public int budj;


    BBVA_Teams(String s, int i) {
        this.budj = i;
        this.nomi = s;
    }

}
