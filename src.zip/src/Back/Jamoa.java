package Back;

public class Jamoa {
    public static void main(String[] args) {
        System.out.println(PlRe.player);
    }
}
