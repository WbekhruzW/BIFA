package Back;

public class User {
    private String ismi;
    private int rate;
    private BBVA_Teams team;
    private String pozzition;
    private int narxi;

    public User(String ismi, int rate, BBVA_Teams team, String pos,int narx) {
        this.ismi = ismi;
        this.rate = rate;
        this.team = team;
        this.narxi = narx;

    }

    @Override
    public String toString() {
        return ismi;
    }
}
